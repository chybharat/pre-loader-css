A Pen created at CodePen.io. You can find this one at https://codepen.io/devilishalchemist/pen/emOVYQ.

 A HTML/CSS copy of one of the preloaders from this Codrops article: http://tympanus.net/codrops/2014/04/25/freebie-flat-style-squared-preloaders/